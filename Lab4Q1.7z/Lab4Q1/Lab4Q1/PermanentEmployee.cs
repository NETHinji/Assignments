﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q1
{
    class PermanentEmployee:Employee
    {
        public int _NoOfLeaves { get; set; }
        public double _ProvidendFund { get; set; }

        public override double GetSalary()
        {
            return _Salary - _ProvidendFund ;

        }
    }
}
