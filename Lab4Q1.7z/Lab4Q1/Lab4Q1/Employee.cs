﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q1
{
    public abstract class Employee
    {
        public int _EmployeeId;
        public string _EmployeeName;
        public string _Address;
        public string _City;
        public string _Department;
        public double _Salary;

        public void setDetails(Employee employee)
        {
            _EmployeeId = employee._EmployeeId;
            _EmployeeName = employee._EmployeeName;
            _Address = employee._Address;
            _City = employee._City;
            _Department = employee._Department;
            _Salary = employee._Salary;

        }
        abstract public double GetSalary();
       
       

    }
}
