﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.WriteLine("Type of employee");
                Console.WriteLine("1.Contract Employee");
                Console.WriteLine("2.Permanent Employee");
                Console.WriteLine("Enter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        ContractEmployee contractEmployee = new ContractEmployee();
                        Console.WriteLine("Enter the Perks:");
                        contractEmployee._Perks = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the salary:");
                        contractEmployee._Salary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Total salary is: " + contractEmployee.GetSalary());
                        break;

                    case 2:
                        PermanentEmployee permanentEmployee = new PermanentEmployee();
                        Console.WriteLine("Enter the NoOfLeaves:");
                        permanentEmployee._NoOfLeaves = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the Providend Fund:");
                        permanentEmployee._ProvidendFund = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Enter the salary:");
                        permanentEmployee._Salary = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("Total salary is: " + permanentEmployee.GetSalary());
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }
            } while (choice != -1);
            Console.ReadLine();
            
        }
    }
}
