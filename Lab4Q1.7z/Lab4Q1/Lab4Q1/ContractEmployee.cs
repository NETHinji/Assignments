﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q1
{
    class ContractEmployee : Employee
    {
        public double _Perks { get; set; }

        public override double GetSalary()
        {
            return _Salary + _Perks;

        }

        
    }
}
