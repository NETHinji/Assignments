﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeEntity
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string EmailId { get; set; }
        public long ContactNo { get; set; }
        public string Designation { get; set; }
    }

    public enum Designation1
    {
        Analyst=0,
        Consultant=1,
        HR=2

    }

}
