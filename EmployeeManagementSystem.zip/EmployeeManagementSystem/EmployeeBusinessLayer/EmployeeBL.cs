﻿using EmployeeDataAcessLayer;
using EmployeeEntity;
using Exception1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeBusinessLayer
{
    public class EmployeeBL
    {

        public int AddEmployee(Employee eobj)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.AddEmployee(eobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public bool EditEmployee(Employee eobj)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.EditEmployee(eobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public bool DeleteEmployee(int employeeid)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.DeleteEmployee(employeeid);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public Employee Search(int EmployeeId)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.Search(EmployeeId);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public DataTable Display()
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.Display();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }

        public DataTable GetDesignation()
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.GetDesignation();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
    }
}
