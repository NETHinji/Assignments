﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeException
{
    public class Exception:ApplicationException
    {
        public Exception() : base()
        {
        }

        public Exception(string message) : base(message)
        {
        }

        public Exception(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
