﻿using EmployeeBusinessLayer;
using EmployeeEntity;
using Exception1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee employee = new Employee();

                //employee.EmployeeId = Convert.ToInt32(txtID.Text);
                employee.EmployeeName = txtName.Text;
                employee.EmailId = txtEmail.Text;

                if(!(Convert.ToInt64(txtContact.Text)>=8000000000 && Convert.ToInt64(txtContact.Text)<=9999999999))
                {
                    throw new EmployeeException("Contact number should start with either 8 or 9");
                }
                else
                {
                    employee.ContactNo = long.Parse(txtContact.Text);
                }
               
                employee.Designation = cmb.SelectedValue.ToString();

                EmployeeBL eb = new EmployeeBL();
                int Eid = eb.AddEmployee(employee);
                MessageBox.Show(string.Format("New Employee Added.\nEmployee Id: {0}", Eid),
                    "Employee Management System");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    EmployeeBL eb = new EmployeeBL();
            //    DataTable dt = eb.GetDesignation();
            //    if (dt != null)
            //    {
            //        cmb.ItemsSource = dt.DefaultView;
            //        cmb.DisplayMemberPath = "DesignationName";
            //        cmb.SelectedValuePath = "DesignationId";
            //    }
            //    else
            //    {
            //        MessageBox.Show("Table is empty", "Employee Management System");
            //    }
            //}
            //catch (EmployeeException ex)
            //{
            //    MessageBox.Show(ex.Message, "Employee Management System");
            //}
            //catch (SystemException ex)
            //{
            //    MessageBox.Show(ex.Message, "Employee Management System");
            //}
            cmb.ItemsSource = Enum.GetValues(typeof(Designation1));
        }

        private void cmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int value = ((int)cmb.SelectedValue);
            MessageBox.Show(value.ToString());
        }
    }
}
