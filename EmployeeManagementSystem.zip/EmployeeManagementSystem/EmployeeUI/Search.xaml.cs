﻿using EmployeeBusinessLayer;
using EmployeeEntity;
using Exception1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeUI
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBL pb = new EmployeeBL();
                Employee emp = pb.Search(int.Parse(txtSearch.Text));
                if (emp != null)
                {
                    txtName.Text = emp.EmployeeName;
                    txtEmail.Text = emp.EmailId;
                    txtContact.Text = emp.ContactNo.ToString();
                    txtDesignation.Text = emp.Designation.ToString();
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Employee with id {0} does not exists.", txtSearch.Text),
                        "Employee Management System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void btn_Del_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Eid = int.Parse(txtSearch.Text);
                EmployeeBL eb = new EmployeeBL();
                if (eb.DeleteEmployee(Eid))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Employee Id " + Eid + " was deleted.");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmployeeId = int.Parse(txtSearch.Text);
                emp.EmployeeName = txtName.Text;
                emp.EmailId = txtEmail.Text;
                emp.ContactNo = long.Parse(txtContact.Text);
                emp.Designation = txtDesignation.Text;
                EmployeeBL eb = new EmployeeBL();
                if (eb.EditEmployee(emp))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Employee Info Saved.", "EmployeeManagement System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
