﻿using EmployeeBusinessLayer;
using Exception1;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeUI
{
    /// <summary>
    /// Interaction logic for Display.xaml
    /// </summary>
    public partial class Display : Window
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBL eb = new EmployeeBL();
                DataTable dt = eb.Display();
                if (dt != null)
                {
                    dgEmployee.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty", "Employee Management System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Employee Management System");
            }
        }
    }
}
