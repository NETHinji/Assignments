--create database employee_db
--go

--use employee_db
--go

create schema Divyesh
go

create table Divyesh.Employee
(
EmployeeId int identity(1,1) primary key,
EmployeeName varchar(25) unique not null,
EmailId varchar(25) not null,
ContactNo bigint not null,
Designation int not null foreign key references Divyesh_Designation(DesignationId)
)
 create schema Divyesh1
 go
create table Divyesh1.Employee
(
EmployeeId int identity(1,1) primary key,
EmployeeName varchar(25) unique not null,
EmailId varchar(25) not null,
ContactNo bigint not null,
Designation varchar(20) not null 
)


create procedure Divyesh1.uspAddEmployee
(
@EName varchar(25),
@EMail varchar(25),
@ContactNo bigint,
@Designation varchar(20),
@EId int output
)
as
begin
	insert into Divyesh1.Employee
	values(@EName,@EMail,@ContactNo,@Designation)
	set @EId = Scope_Identity()
end

create table Divyesh_Designation
(
 DesignationId int identity(1,1) primary key,
 DesignationName varchar(20) unique not null
)

insert into Divyesh_Designation values('Analyst'),('Consultant'),('HR'),('CEO')
select * from Divyesh.Employee
select * from Divyesh_Designation
drop table Divyesh_Designation
drop table Divyesh1.Employee

create procedure Divyesh1.uspGetDesignation1
as
begin
	select DesignationId,DesignationName 
	from Divyesh_Designation
	order by DesignationId
end

create proc Divyesh1.uspDeleteEmployee
(
@EId int
)
as
begin
	delete from Divyesh1.Employee
	where EmployeeId = @Eid
end

create proc Divyesh1.uspSearchEmployee
(
@EId int
)
as
begin
	select * from Divyesh1.Employee
	where EmployeeId = @Eid
end

create proc Divyesh1.uspEditEmployee
(
@EId int,
@EName varchar(25),
@EMail varchar(25),
@ContactNo bigint,
@Designation varchar(20)
)
as
begin
	update Divyesh1.Employee
	set EmployeeName = @EName,EmailId=@EMail,
	ContactNo=@ContactNo,Designation=@Designation
	where EmployeeId = @EId
end

create proc Divyesh1.uspGetEmployees
as
begin
select * from Divyesh1.Employee
end