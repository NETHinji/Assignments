﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Lab12_Q2
{
    class Lab12_Q2 { 

        static void Main(string[] args)
        {
            try
            {
                string data1,data2;
                data1 = @"D:\File1.txt";
                string Content1 = File.ReadAllText(data1);
                Console.WriteLine(Content1);
                data2 = @"D:\File2.txt";
               
                File.Copy(data1,data2,true);
                string Content2 = File.ReadAllText(data2);
                Console.WriteLine(Content2);


            }
            catch(Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }
        }
    }
}
