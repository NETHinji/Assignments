﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccesssLayer;
using Entity;
using Exceptions;
using System.Data;
namespace BusinessLayer
{
    public class MyProductBL
    {
        public int AddProduct(Product pobj)
        {
            try
            {
                MyProductDAL pd = new MyProductDAL();
                return pd.AddProduct(pobj);
            }
            catch (ProductException)
            {
                throw;
            }
        }
        public DataTable GetCategories()
        {
            try
            {
                MyProductDAL pd = new MyProductDAL();
                return pd.GetCategories();
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}