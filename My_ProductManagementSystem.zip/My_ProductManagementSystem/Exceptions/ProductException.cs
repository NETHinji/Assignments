﻿using System;
using System.Runtime.Serialization;

namespace Exceptions
{
    public class ProductException : ApplicationException
    {
        public ProductException() : base()
        {
        }

        public ProductException(string message) : base(message)
        {
        }

        public ProductException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}