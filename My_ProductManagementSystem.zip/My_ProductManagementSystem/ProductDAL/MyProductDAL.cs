﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Exceptions;
using Entity;

namespace DataAccesssLayer
{
    public class MyProductDAL
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pboj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;

        static MyProductDAL()
        {
            conStr =ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public MyProductDAL()
        {
            con = new SqlConnection(conStr);

        }
        public int AddProduct
               
            (Product pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 



                cmd = new SqlCommand();
                cmd.CommandText = "Geetha_ak.uspAddProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@pId", SqlDbType.Int);
                cmd.Parameters["@pId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@pName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descp", pboj.Description);
                cmd.Parameters.AddWithValue("@up", pboj.UnitPrice);
                cmd.Parameters.AddWithValue("@st", pboj.Stock);
                cmd.Parameters.AddWithValue("@cat", pboj.Category);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        public DataTable GetCategories()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha_ak.uspGetCategories";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new ProductException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new ProductException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
