﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;


namespace ProductMock.Except
{
    
    public class ProductMockExceptions : Exception
    {
        public ProductMockExceptions()
        {
        }

        public ProductMockExceptions(string message) : base(message)
        {
        }

        public ProductMockExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ProductMockExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}