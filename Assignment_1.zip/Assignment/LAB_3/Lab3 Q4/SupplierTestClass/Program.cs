﻿using Supplier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Supplier.BusinessLogic;


namespace SupplierTestClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Supplier1 supplier = new Supplier1();


            supplier = AcceptDetails();
            SupplierBL.IsValidSupplier(supplier);


             Supplier1 AcceptDetails()
            {

                  Random random = new Random();
                     supplier.SupplierId = random.Next();

                Console.WriteLine("Enter the Name of Supplier");
                supplier.SupplierName = Console.ReadLine();



                Console.WriteLine("Enter the City of Supplier");
                supplier.City = Console.ReadLine();

                Console.WriteLine("Enter the Phone Number of Supplier");
                supplier.PhoneNo = Console.ReadLine();

                Console.WriteLine("Enter the Email of Supplier");
                supplier.Email = Console.ReadLine();

               

                return supplier;
                Console.ReadKey();

            }








        }
    }
}
