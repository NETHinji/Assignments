﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car
{
    class Car
    {
        public string CarMake { get; set; }
        public string CarModel { get; set; }
        public int CarPrice { get; set; }
        public int CarYear { get; set; }
        static List<Car> cars = new List<Car>();
        static public int count=0;
        

        public Car()
        {
            this.CarMake = "ABC";
            this.CarModel = "XYZ";
            this.CarPrice = 1000000;
            this.CarYear = 2000;

        }
        public Car(string CarMake, string CarModel, int CarPrice, int CarYear)
        {
            this.CarMake = CarMake;
            this.CarModel = CarModel;
            this.CarPrice = CarPrice;
            this.CarYear = CarYear;
        }


        public static void AddCar()
        {

            try
            {
                Console.Write("Enter Car make: ");
                string carMake = Console.ReadLine();
                Console.Write("Enter Car model: ");
                string carModel = Console.ReadLine();
                Console.Write("Enter Car Price: ");
                int carPrice = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Car Year: ");
                int carYear = Convert.ToInt32(Console.ReadLine());
                Car car = new Car(carMake, carModel, carPrice, carYear);
                cars.Add(car);
                Console.WriteLine("Car added Succesfully");
            }
            catch (Exception)
            {

                throw;
            }
                     }

        public static void ModifyCar()
        {
            
        }

        public static void SearchCar()
        {
            try
            {
                int searchYear = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Found : " + cars.Find(item => item.CarYear == searchYear));
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void ListCar()
        {
            try
            {
                foreach(Car item in cars)
                {
                    Console.WriteLine(item.ToString());

                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void DeleteCar()
        {
            try
            {
                int deleteCarYear;
                Console.WriteLine("Enter Year of car to Delete:");
                deleteCarYear = Convert.ToInt32(Console.ReadLine());

                if (cars.Exists(item => item.CarYear == deleteCarYear))
                    cars.Remove(cars.Find(item => item.CarYear == deleteCarYear));
            }
            catch (Exception)
            {
                throw;
            }
        }
        public override string ToString()
        {
            return "Car make: " + CarMake + " Car model: " + CarModel + " Car Price: " + CarPrice + " Car Year: " + CarYear;
        }
    }
}
