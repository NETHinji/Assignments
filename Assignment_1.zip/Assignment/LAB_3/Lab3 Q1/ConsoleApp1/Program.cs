﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Library;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Participant participant = new Participant(160919, "Tamal", "Capgemini", -9, 67, 45, 300);
                participant.CalculateTotal();
                participant.CalculatePercentage();
                Console.WriteLine($"The percentage is {participant.Returnpercentage()}%");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
