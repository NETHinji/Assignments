﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Library
{
    public class Participant
    {
        int empId;
        string name;
        static string comapany_name;
        int foundationmarks;
        int webbasicsmarks;
        int dotnetmarks;
        int totalmarks;
        int obtainedmarks;
        decimal percentage;
        public int _EmpId { get; set; }
        public string _Name { get; set; }
        public string _Company_Name { get; set; }
        public int _Foundationmarks { get; set; }
        public int _Webbasicsmarks { get; set; }
        public int _Dotnetmarks { get; set; }
        public int _Totalmarks { get; set; }
        public int _Obtainedmarks { get; set; }
        public decimal _Percentage { get; set; }
        public int _Maxvalidate { get; set; }
        public int _Minvalidate { get; set; }

        public Participant()
        {
            empId = 0;
            name = null;
            comapany_name = null;
            foundationmarks = 0;
            webbasicsmarks = 0;
            dotnetmarks = 0;
            totalmarks = 300;
            obtainedmarks = 0;
            percentage = 0;
            
        }
        public Participant(int e,string n,string cn,int f,int w,int d,int t)
        {
            try
            {
                _Maxvalidate = 100;
                _Minvalidate = 0;
                empId = e;
                name = n;
                comapany_name = cn;
                if (f >= 0 && f <= 100 & w >= 0 && w <= 100 & d >= 0 && d <= 100)
                {
                    foundationmarks = f;
                    webbasicsmarks = w;
                    dotnetmarks = d;
                }
                else
                {
                    throw new Exception1(_Maxvalidate, _Minvalidate);
                    f = 0;
                    w = 0;
                    d = 0;

                }
                totalmarks = t;
            }
            catch (Exception ex)
            {

                Console.WriteLine();
            }
           
        }
        static Participant()
        {
             comapany_name = "Corporate University";
        }
        public void CalculateTotal()
        {
            obtainedmarks = foundationmarks + webbasicsmarks + dotnetmarks;
        }
        public void CalculatePercentage()
        {
            try
            {
                percentage = (obtainedmarks * 100) / totalmarks;
            }
            catch (Exception ex)
            {

                Console.WriteLine();
            }
        }
        public decimal Returnpercentage()
        {
            return percentage;
        }
    }
}
