﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculater
{
    class Program
    {
        static void Menu()
        {
            
            Console.WriteLine("Select an arithmatic operation");
            Console.WriteLine("1)Addition");
            Console.WriteLine("2)Subtraction");
            Console.WriteLine("3)Multiplication");
            Console.WriteLine("4)Division");
            Console.WriteLine("5)Find Max");
            Console.WriteLine("6)Quit");
            
        }



        static void Main(string[] args)
        {
            PerformArithmeticOperation PAO = new PerformArithmeticOperation();
            int operation;
            
            double x, y;

            do
            {
                Console.WriteLine("Enter two numbers seperated by Enter");
                x = double.Parse(Console.ReadLine());
                y = double.Parse(Console.ReadLine());
                Console.Clear();

                Menu();
                
                operation = int.Parse(Console.ReadLine());


                PAO.PerformArithmeticOp(x,y,operation);
                Console.WriteLine("Press any key to continue");
                Console.ReadKey(true);
                Console.Clear();
            } while (operation != 6);
        }
    }
}
