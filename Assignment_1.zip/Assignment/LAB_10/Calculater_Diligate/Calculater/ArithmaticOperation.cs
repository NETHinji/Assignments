﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculater
{
    class ArithmeticOperation
    {
        public void Add(double a, double b)
        {
            Console.WriteLine(a + b);
        }

        public void Subtract(double a, double b)
        {
            Console.WriteLine(a - b);
        }

        public void Multiply(double a, double b)
        {
            Console.WriteLine(a * b);
        }

        public void Divide(double a, double b)
        {
            Console.WriteLine(a / b);
        }

        public void FindMax(double a, double b)
        {
            if (a > b) Console.WriteLine(a);
            else Console.WriteLine(b);
        }
    }
}
