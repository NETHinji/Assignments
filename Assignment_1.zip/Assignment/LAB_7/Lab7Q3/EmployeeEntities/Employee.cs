﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeEntities
{
    public class Employee
    {
        private int _employeeID;
        private string _employeeName;
        private int _basicSalary;
        private int _pf;

        public int EmployeeID
        { get; set; }
        public string EmployeeName
        { get; set; }
        public int BasicSalary
        { get; set; }
        public int Pf
        { get; set; }

        public Employee()
        {
            _employeeID = 0;
            _employeeName = string.Empty;
            _basicSalary = 0;
            _pf = 0;
        }

        public Employee(int id, string employeeName, int basicSalary, int pf)
        {
            _employeeID = id;
            _employeeName = employeeName;
            _basicSalary = basicSalary;
            _pf = pf;
        }
    }
}
