﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntities;

namespace EmployeeDetails
{
    class EmployeePL
    {
        static void Main(string[] args)
        {
            Employee newEmployee = new Employee(1, "Vidya", 200000, 1704);
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        ViewEmployee();
                        break;
                    case 3:
                        SearchEmployeeByID();
                        break;
                    case 4:
                        DeleteEmployee();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }
        public static List<Employee> employeeList = new List<Employee>();
        
        private static void AddEmployee()
        {
            try
            {
                Employee newEmployee = new Employee();
                Console.WriteLine("Enter EmployeeID :");
                newEmployee.EmployeeID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Employee Name :");
                newEmployee.EmployeeName = Console.ReadLine();
                Console.WriteLine("Enter Basic Salary :");
                newEmployee.BasicSalary = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter PF :");
                newEmployee.Pf = Convert.ToInt32(Console.ReadLine());

                employeeList.Add(newEmployee);
                    Console.WriteLine("Employee Added");
            }
            catch (SystemException ex)
            {
                Console.WriteLine("Employee Not Added");
            }
        }

        private static void ViewEmployee()
        {
            Console.WriteLine("******************************************************************************");
            Console.WriteLine("EmployeeID\t\tName\t\tBasic salary\t\tPF");
            Console.WriteLine("******************************************************************************");
            foreach (Employee employee in employeeList)
            {
                Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", employee.EmployeeID, employee.EmployeeName, employee.BasicSalary, employee.Pf);
            }
            Console.WriteLine("******************************************************************************");

        }

        private static void SearchEmployeeByID()
        {
            try
            {
                Employee searchEmployee = new Employee();
                int searchEmployeeID;
                Console.WriteLine("Enter EmployeeID to Search:");
                searchEmployeeID = Convert.ToInt32(Console.ReadLine());

                searchEmployee = employeeList.Find(employee => employee.EmployeeID == searchEmployeeID);
                Console.WriteLine("******************************************************************************");
                Console.WriteLine("EmployeeID\t\tName\t\tBasic salary\t\tPF");
                Console.WriteLine("******************************************************************************");
                Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchEmployee.EmployeeID, searchEmployee.EmployeeName, searchEmployee.BasicSalary, searchEmployee.Pf);
                Console.WriteLine("******************************************************************************");
            }
            catch (SystemException ex)
            {
                Console.WriteLine("No Employee Details Available");
            }
        }
        private static void DeleteEmployee()
        {
            try
            {
                int deleteEmployeeID;
                Console.WriteLine("Enter EmployeeID to Delete:");
                deleteEmployeeID = Convert.ToInt32(Console.ReadLine());
                Employee deleteEmployee = employeeList.Find(employee => employee.EmployeeID == deleteEmployeeID);
                employeeList.Remove(deleteEmployee);
                Console.WriteLine("Employee Deleted");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Employee Not Deleted");
            }
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Guest PhoneBook Menu***********");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. List All Employees");
            Console.WriteLine("3. Search Employee by ID");
            Console.WriteLine("4. Delete Employee");
            Console.WriteLine("5. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
