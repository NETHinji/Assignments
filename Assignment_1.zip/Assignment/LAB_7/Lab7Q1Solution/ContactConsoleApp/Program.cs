﻿using Lab7ContactQ1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactConsoleApp
{
    class Program
    {
        static List<Contact> ContactList = new List<Contact>();
        static void Main(string[] args)
        {
            int ch;
            do
            {
                //Printing Menu List
                PrintMenu();

                Console.WriteLine("Enter Your Choice");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        bool contAdded=AddContact();
                        if (contAdded)
                        {
                            Console.WriteLine(Environment.NewLine);
                            Console.WriteLine("Contact Added");
                        }
                        else
                        {
                            Console.WriteLine("Contact not Added");
                        }
                        break;

                    case 2:
                        DisplayContact();
                        break;

                    case 3:
                        bool contactEdited=EditContact();
                        if(contactEdited)
                        {
                            Console.WriteLine("Contact Edited");
                        }
                        else
                        {
                            Console.WriteLine("Contact Details Not Available");
                        }
                        break;

                    case 4:
                        ShowAllContacts();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice?????");
                        break;
                }
            } while (ch!=-1);


        }

        //Displaying All the Added Contacts
        private static void ShowAllContacts()
        {
            try
            {
                Contact contact = new Contact();
                if (ContactList != null)
                {
                    Console.WriteLine("=============================================================");
                    Console.WriteLine("Contact No.\tContact Name\tCell No.");
                    Console.WriteLine("=============================================================");
                    foreach (Contact gate in ContactList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", gate.ContactNo, gate.ContactName, gate.CellNo);
                    }
                    Console.WriteLine("=============================================================");
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        //Updating an Existing Contact
        private static bool EditContact()
        {
            bool contactUpdated = false;
            Console.WriteLine("Enter Contact Number to search Contact Details:");
            int cn = Convert.ToInt32(Console.ReadLine());
            Contact cont=SearchContact(cn);
            if(cont != null)
            {
                Console.WriteLine("Enter Update Contact Name:");
                cont.ContactName = Console.ReadLine();
                Console.WriteLine("Enter Update Cell Number:");
                cont.CellNo = Console.ReadLine();

                for (int i = 0; i < ContactList.Count; i++)
                {
                    if (ContactList[i].ContactNo == cont.ContactNo)
                    {
                        cont.ContactName = ContactList[i].ContactName;
                        cont.CellNo = ContactList[i].CellNo;
                        contactUpdated = true;
                    }
                }
            }
            return contactUpdated;
        }

        //Searching contact details based on 
        private static Contact SearchContact(int cno)
        {
            Contact searchContact = new Contact();

            searchContact = ContactList.Find(c1 => c1.ContactNo == cno);
            return searchContact;
        }

        private static void DisplayContact()
        {

            Console.WriteLine("Enter Contact no. of which you want details:");
            int no = Convert.ToInt32(Console.ReadLine());
            Contact detailsFound=SearchContact(no);
            if(detailsFound.ContactNo==no)
            {
                Console.WriteLine("=============================================================");
                Console.WriteLine("Contact No.\tContact Name\tCell No.");
                Console.WriteLine("=============================================================");
                Console.WriteLine("{0}\t\t{1}\t\t{2}", detailsFound.ContactNo, detailsFound.ContactName, detailsFound.CellNo);
                Console.WriteLine("=============================================================");
            }
            else
            {
                Console.WriteLine("Contact Details Not Found...");
            }
        }

        static bool AddContact()
        {
            bool contactAdded = false;

            try
            {
                Contact c1 = new Contact();

                Console.WriteLine("Enter Contact Number:");
                c1.ContactNo = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Contact Name:");
                c1.ContactName = Console.ReadLine();

                Console.WriteLine("Enter Cell Number:");
                c1.CellNo = Console.ReadLine();

                ContactList.Add(c1);
                contactAdded = true;
            }
            catch (SystemException sys)
            {
                Console.WriteLine(sys.Message);
            }
            return contactAdded;
        }
        public static void PrintMenu()
        {
            Console.WriteLine("1. Add Contact");
            Console.WriteLine("2. Display Contact");
            Console.WriteLine("3. Edit Contact");
            Console.WriteLine("4. Show All Contacts");
        }
    }
}
