﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7Que2
{
    class Program
    {

        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;
                    case 2:
                        DeleteProduct();
                        break;
                    case 3:
                        SearchProduct();
                        break;
                    case 4:
                        SortProduct();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);

        }

        public static void PrintMenu()
        {
            Console.WriteLine("====================================");
            Console.WriteLine("1. Add New Product");
            Console.WriteLine("2. Delete  Product");
            Console.WriteLine("3. Search Product");
            Console.WriteLine("4. Save New Product in Sorted Order");
            Console.WriteLine("===================================");
        }

        public static void AddProduct()
        {
            try
            {
                Product product = new Product();

                Console.WriteLine("Enter Product Number");
                product.ProductNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                product.ProductName = Console.ReadLine();
                Console.WriteLine("Enter Product Rate");
                product.ProductRate = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter Product Stock");
                product.ProductStock = Convert.ToSingle(Console.ReadLine());

                ProductMethods.AddPro(product);

                Console.WriteLine("\nProduct Added!\n");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteProduct()
        {
            try
            {
                int deleteProduct;
                Console.WriteLine("Enter Product Number to Delete from List");
                deleteProduct = Convert.ToInt32(Console.ReadLine());

                ProductMethods.DeletePro(deleteProduct);

                Console.WriteLine("\nProduct Deleted!\n");
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public static void SearchProduct()
        {
            try
            {
                int searchProduct;
                Console.WriteLine("Enter Product Number to Serarch from List");
                searchProduct = Convert.ToInt32(Console.ReadLine());

                Product searchPro = ProductMethods.SearchPro(searchProduct);

                if (searchPro != null)
                {
                    Console.WriteLine("=====================================================================");
                    Console.WriteLine("ProductNumber\tProductName\tProductRate\tProductStock\t");
                    Console.WriteLine("=====================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchPro.ProductNo, searchPro.ProductName, searchPro.ProductRate, searchPro.ProductStock);
                    Console.WriteLine("=====================================================================");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void SortProduct()
        {
            try
            {
                List<Product> proList = ProductMethods.SortProduct();
                Console.WriteLine("\nProducts Sorted According to Product Number!\n");

                Console.WriteLine("=====================================================================");
                Console.WriteLine("ProductNumber\tProductName\tProductRate\tProductStock\t");
                Console.WriteLine("=====================================================================");
                foreach (Product p in proList)
                {
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", p.ProductNo, p.ProductName, p.ProductRate, p.ProductStock);
                }
                Console.WriteLine("=====================================================================");
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
