﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7Que2
{
    class ProductMethods
    {
        public static List<Product> productList = new List<Product>();

        public static void AddPro(Product product)
        {
            try
            {
                productList.Add(product);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public static void DeletePro(int deletePro)
        {
            try
            {
                Product deleteProduct = productList.Find(pro => pro.ProductNo == deletePro);

                if (deleteProduct != null)
                {
                    productList.Remove(deleteProduct);
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public static Product SearchPro(int searchProNo)
        {
            Product searchPro = null;
            try
            {
                searchPro = productList.Find(pro => pro.ProductNo == searchProNo);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return searchPro;
        }

        public static List<Product> SortProduct()
        {
            productList.Sort((a, b) => a.ProductNo.CompareTo(b.ProductNo));

            return productList;
        }

    }
}
