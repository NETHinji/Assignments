﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7Que2
{
    class Product
    {
        public int ProductNo;
        public string ProductName;
        public float ProductRate, ProductStock;

        public Product()
        {
            ProductNo = 0;
            ProductName = string.Empty;
            ProductRate = 0.0f;
            ProductStock = 0.0f;
        }
    }
}
