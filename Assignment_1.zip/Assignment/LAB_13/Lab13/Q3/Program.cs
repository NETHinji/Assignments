﻿using Lab13;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Collections;
using System.Runtime.Serialization.Formatters.Soap;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static ArrayList contacts = new ArrayList();
        static void Main(string[] args)
        {
            if (File.Exists(@"D:\\MyElementList.xml"))
                SOAPDeserialize();
            Contact contact = new Contact();
            Console.WriteLine("Enter the contact number:");
            contact.ContactNo = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter the name:");
            contact.ContactName = Console.ReadLine();
            Console.WriteLine("Enter cell no");
            contact.CellNo = Console.ReadLine();
            AddContact(contact);
            SOAPSerialize();
        }
        public static void AddContact(Contact contact)
        {
            contacts.Add(contact);
        }
        private static void SOAPSerialize()
        {
            Stream streamWrite = File.Create(@"D:\\MyElementList.xml");
            SoapFormatter soapWrite = new SoapFormatter();
            soapWrite.Serialize(streamWrite, contacts);
            streamWrite.Close();
        }
        private static void SOAPDeserialize()
        {
            Stream streamRead = File.OpenRead(@"D:\\MyElementList.xml");
            SoapFormatter soapRead = new SoapFormatter();
            contacts = (ArrayList)soapRead.Deserialize(streamRead);
            streamRead.Close();
            foreach (Contact contact in contacts)
            {
                Console.WriteLine("{0}, {1}, {2}",
                   contact.CellNo, contact.ContactName, contact.ContactNo);
            }
        }
    }
}
