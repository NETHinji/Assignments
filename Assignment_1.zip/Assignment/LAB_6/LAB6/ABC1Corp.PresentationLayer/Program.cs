﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABC1Corp.Exceptions;
using ABCCustomer.Entity;

namespace ABC1Corp.PresentationLayer
{
    class Program
    {
        public static List<Customer> custList = new List<Customer>();
        static void Main(string[] args)
        {


            int choice = 0;
            do
            {
                Console.WriteLine("*********ABC CORP************");
                Console.WriteLine("\t1:Add customer Data\n\t2:Display customers Data\n\t3:Exit");

                Console.WriteLine("enter your choice from above list");

                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        Add();
                        break;


                    case 2:
                        Display();
                        break;
                    case 3:
                        return;


                        //Console.WriteLine("enter correct choice");

                }
            } while (choice <= 3);


        }

        private static void Display()
        {
            if (custList != null)
            {
                Console.WriteLine("******************************************************************************");
                Console.WriteLine("Cust_Id\t\tName\t\taddress\t\tcity\t\tphone\t\t\ncreditlimit\n");
                Console.WriteLine("******************************************************************************");
                foreach (Customer cust in custList)
                {
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t\n{5}", cust.CustomerId,cust.CustomerName, cust.Address,cust.City,cust.Phone,cust.CreditLimit);
                }
                Console.WriteLine("******************************************************************************");

            }
            else
            {
                Console.WriteLine("No Guest Details Available");
            }










        }

        private static bool validateCustomer(Customer customer)
        {
            bool validatecreditLimit = false;

            if (customer.CreditLimit > 50000)
            {

                throw new InvalidCreditLimitException(customer.CreditLimit.ToString());
            }
            else
            {
                validatecreditLimit = true;

            }
            return validatecreditLimit;
        }


        private static void Add()
        {


            Customer newCustomer = new Customer();

            bool isvalidate = false;
            try
            {

                Console.WriteLine("Enter Customer Id");
                newCustomer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Custome Name");
                newCustomer.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Custome Address");
                newCustomer.Address = Console.ReadLine();
                Console.WriteLine("Enter Custome City");
                newCustomer.City = Console.ReadLine();

                Console.WriteLine("Enter credit limit of Customer");
                newCustomer.CreditLimit = Convert.ToDouble(Console.ReadLine());

                isvalidate = validateCustomer(newCustomer);
                if (isvalidate == true)
                {
                    Add1(newCustomer);
                }



            }
            catch (InvalidCreditLimitException ex)
            {
                Console.WriteLine("" + ex.Message);
            }








        }

        private static void Add1(Customer newCustomer)
        {



            custList.Add(newCustomer);

            Console.WriteLine("data added successfully");


        }
    }
}
