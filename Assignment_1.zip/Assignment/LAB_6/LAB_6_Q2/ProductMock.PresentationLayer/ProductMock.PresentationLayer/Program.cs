﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductMock.Entities;
using ProductMock.BusinessLayer;
using ProductMock.Except;

namespace ProductMock.PresentationLayer
{
    class Program
    {
        

        static void Main(string[] args)
        {
           
            int Choice = 0;
            do
                {

                PrintMenu();
            
                Choice = Convert.ToInt32(Console.ReadLine());
              
                switch(Choice)
                {
                    case 1:
                        {
                            CheckID();
                          
                            break;
                        }
                    case 2:
                        {
                            CheckName();
                           
                            
                            break;
                        }
                    case 3:
                        {
                            CheckPrice();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Wrong Choice Entered");
                            break;
                        }

                }

            }while (Choice != -1) ;
        }

        private static void CheckID()
        {
            
            try
            {
                Entity EP = new Entity();
                EP.ProductId = Convert.ToInt32(Console.ReadLine());
                bool IDValidated = ProductLogic.ValidateID(EP);
                if(IDValidated)
                {
                    Console.WriteLine("ID IS CORRECT");
                }
            }
            catch (ProductMockExceptions )
            {
                Console.WriteLine("Product ID must be greater than zero");
            }
        }
      
        private static void CheckName()
        {
            try
            {
                Entity EP = new Entity();
                EP.ProductName = Console.ReadLine();
                bool NameValidated = ProductLogic.ValidateName(EP);
                if(NameValidated)
                {
                    Console.WriteLine("Name Validated");
                }
            }
            catch (ProductMockExceptions)
            {
                Console.WriteLine("Product name can not be left blank");
            }
           

        }

        private static void CheckPrice()
        {
            try
            {
                Entity EP = new Entity();
                EP.ProductPrice = Convert.ToInt32(Console.ReadLine());
                bool PriceValidated = ProductLogic.ValidatePrice(EP);
                if(PriceValidated)
                {
                    Console.WriteLine("Entered Price is Correct");
                }
            }
            catch(ProductMockExceptions )
            {
                Console.WriteLine("Price of product must be greater than zero");
            }
           

        }



        private static void PrintMenu()
        {
            Console.WriteLine("*********** ProductMock***********");
            Console.WriteLine("1.Enter the product id");
            Console.WriteLine("2.Enter the product name");
            Console.WriteLine("3.Enter the product price");
            Console.WriteLine("Enter your choice");
            Console.WriteLine("*********** ProductMock***********");


        }
    }
}
