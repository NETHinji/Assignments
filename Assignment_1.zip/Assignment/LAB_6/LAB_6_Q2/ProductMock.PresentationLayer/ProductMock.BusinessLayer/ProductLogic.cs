﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductMock.Entities;
using ProductMock.Except;

namespace ProductMock.BusinessLayer
{
    public class ProductLogic
    {
        static StringBuilder Sb = new StringBuilder();
        public static bool ValidateID(Entity EP)
        {
            bool ValidateDID = true;
            if (EP.ProductId <= 0)
            {
                ValidateDID = false;
                Sb.Append(Environment.NewLine + "Product ID must be greater than zero");
            }


            if (ValidateDID == false)
            {
                throw new ProductMockExceptions(Sb.ToString());
            }


            return ValidateDID;
        }

        public static bool ValidateName(Entity EP)
        {
            bool Validatename = true;
            if (EP.ProductName == "")
            {
                Validatename = false;
                Sb.Append("Product Name cannot be left blank");
            }

            if (Validatename== false)
            {
                throw new ProductMockExceptions(Sb.ToString());
            }
            return Validatename;
        }

        public static bool ValidatePrice(Entity EP)
        {
            bool Validateprice = true;
            if (EP.ProductPrice <= 0)
            {
                Validateprice = false;
                Sb.Append("Price of Product must be greater than zero");
            }


            if (Validateprice == false)
            {
                throw new ProductMockExceptions(Sb.ToString());
            }
            return Validateprice;
        }



    }
}
