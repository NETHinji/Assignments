﻿using System;
using System.Runtime.Serialization;

namespace ProductMock
{
    [Serializable]
    public class Exceptions : Exception
    {
        public Exceptions()
        {
        }

        public Exceptions(string message) : base(message)
        {
        }

        public Exceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected Exceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}