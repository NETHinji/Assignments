﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductMock.Entities
{
   
      public class Entity
        {
            private int productId;

            public int ProductId { get => productId; set => productId = value; }

            public string ProductName;

            private int productPrice;

            public int ProductPrice { get => productPrice; set => productPrice = value; }
        }
    
}
