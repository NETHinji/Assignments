﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ProductMock.Except")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ProductMock.Except")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c3b90264-82b4-4961-bfae-bf65c7aba8bc")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace ProductMock.Except.Properties
{
    [Serializable]
    public class ProductMockExceptions : Exception
    {
        private Func<string> toString;

        public ProductMockExceptions()
        {
        }

        public ProductMockExceptions(Func<string> toString)
        {
            this.toString = toString;
        }

        public ProductMockExceptions(string message) : base(message)
        {
        }

        public ProductMockExceptions(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ProductMockExceptions(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}