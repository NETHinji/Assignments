﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_Lab8
{
    class Data
    {
        static Hashtable _ht = new Hashtable();

        public static void AddRecord()
        {
            Console.WriteLine("Enter the record");
            string districtCode = Console.ReadLine();
            string districtName = Console.ReadLine();
            _ht.Add(districtCode, districtName);
        }

        public static void SearchList()
        {
            string searchCode = Console.ReadLine();
            ICollection key = _ht.Keys;
            if (_ht.ContainsKey(searchCode))
                Console.WriteLine("Code : " + searchCode + "  District : " + _ht[searchCode] + " is present");
            else
                Console.WriteLine("There is no record with such Code");
        }

        public static void DisplayCount()
        {
            Console.WriteLine("Count of keys"+ _ht.Count);
        }

        public static void RemoveList()
        {
            string removeCode = Console.ReadLine();
            if (_ht.ContainsKey(removeCode))
            {
                Console.WriteLine("Code : " + removeCode + "  District : " + _ht[removeCode] + " is removed");
                _ht.Remove(removeCode);
            }
            else
                Console.WriteLine("There is no record with such Code");
        }

        public static void DisplayList()
        {
            ICollection key = _ht.Keys;
            foreach (string k in key)
                Console.WriteLine(k + ": " + _ht[k]);
        }
    }
}
