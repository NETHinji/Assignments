﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    public delegate void Payment();
    class CreditCard
    {
        int CreditCardNo;
        string CardHolderName;
        int BalanceAmount;
        int CreditLimit;
        public CreditCard()
        {
            BalanceAmount = 100000;
            CreditLimit = 200;
        }
        public event Payment Make;
        public int GetBalance()
        {
            return BalanceAmount;
        }
        public int GetCreditLimit()
        {
            return CreditLimit;
        }
        public void MakePayment(int amount)
        {
           
                BalanceAmount -= amount;
                Make();
        }
        public void SentMessage()
        {
            if (BalanceAmount>0)
                Console.WriteLine("Your payment is made and current balance is " + BalanceAmount);
            else
                Console.WriteLine("Sorry payment cannot be made");
        }
    }
}
