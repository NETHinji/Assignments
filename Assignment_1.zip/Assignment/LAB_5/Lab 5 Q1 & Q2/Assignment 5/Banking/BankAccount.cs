﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{


    public abstract class BankAccount : IBankAccount
    {



        public BankAccountTypeEnum BankAccountType;
        protected double _Balance;
        double _Amount;

        public BankAccount()
        {

            _Balance = 0;
            _Amount = 0;
        }

        public double Balance {
            get { return _Balance; }
            set { _Balance = value; }
        }

        public double Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }

        public BankAccountTypeEnum AccountType { get => throw new NotImplementedException();
            set => throw new NotImplementedException(); }

        public void GetBalance()
        {

            Console.WriteLine("Current Balance:{0}", Balance);


        }



        public abstract bool Withdraw(double amount);

        public void Deposit(double amount)
        {

            double Amount;
            Amount = amount;
            Balance = Balance + Amount;
            Console.WriteLine("Money Deposited. Account Balance is {0}", Balance);

        }

        public abstract void CalculateInterest();
       
    }
       
    }

