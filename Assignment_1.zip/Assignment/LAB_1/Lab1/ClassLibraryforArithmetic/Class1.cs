﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2Library

{
    public class ArithMeticOperation
    {

        public double Add(int a, double b)
        {
            return a + b;
        }
        public double Substract(int a, double b)
        {
            return a - b;
        }
        public double Multiply(int a, double b)
        {
            return a * b;
        }
        public double Division(int a, double b)
        {
            return a / b;
        }
        public double Modulus(int a, double b)
        {
            return a % b;
        }
    }
}
