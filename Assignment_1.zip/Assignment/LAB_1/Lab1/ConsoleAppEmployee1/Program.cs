﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Task1Library;

namespace Q1Task2

{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e = new Employee();
            e._EmployeeId = 160919;
            e._EmployeeName = "Tamal Adhikari";
            e._Address = "2C Road";
            e._City = "Pune";
            e._Department = ".NET";
            e._Salary = 17000;
            e.setDetails(e);
        }
    }
}
