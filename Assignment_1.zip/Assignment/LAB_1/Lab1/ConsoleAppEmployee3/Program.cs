﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Task1Library;

namespace Q1Task3

{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] employees = new Employee[10];
            for (int k = 0; k < employees.Length; k++)
                employees[k] = new Employee();
            int counter = 0;
            int id = 0;
            string name = null;
            string addr = null;
            string city = null;
            string dept = null;
            double sal = 0;
            for (int j = 0; j < employees.Length; j++)
            {
                Console.WriteLine("Enter the id of employee {0}", counter);
                id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the name of employee {0}", counter);
                name = Console.ReadLine();
                Console.WriteLine("Enter the address of employee {0}", counter);
                addr = Console.ReadLine();
                Console.WriteLine("Enter the city of employee {0}", counter);
                city = Console.ReadLine();
                Console.WriteLine("Enter the department of employee {0}", counter);
                dept = Console.ReadLine();
                Console.WriteLine("Enter the salary of employee {0}", counter);
                sal = Convert.ToDouble(Console.ReadLine());
                counter++;
                employees[j].setDetails(employees[j]);
            }
            counter = 0;
            for (int i = 0; i < employees.Length; i++)
            {
                Console.WriteLine($"Name of employee {counter} is " + employees[i]._EmployeeName + " and salary is " + employees[i].getSalary());
                counter++;
            }
            Console.ReadLine();

        }
    }
}
