﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q2Library;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithMeticOperation arithMeticOperation = new ArithMeticOperation();
            Console.WriteLine("Enter your choice:");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 1st number:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number");
            double b = Convert.ToDouble(Console.ReadLine());
            switch (c)
            {
                case 1:
                    Console.WriteLine("The result is: " + arithMeticOperation.Add(a, b));
                    break;
                case 2:
                    Console.WriteLine("The result is: " + arithMeticOperation.Substract(a, b));
                    break;
                case 3:
                    Console.WriteLine("The result is: " + arithMeticOperation.Multiply(a, b));
                    break;
                case 4:
                    Console.WriteLine("The result is: " + arithMeticOperation.Division(a, b));
                    break;
                case 5:
                    Console.WriteLine("The result is: " + arithMeticOperation.Modulus(a, b));
                    break;
                default:
                    Console.WriteLine("Wrong choice");
                    break;
            }
            Console.ReadLine();
        }
    }
}
