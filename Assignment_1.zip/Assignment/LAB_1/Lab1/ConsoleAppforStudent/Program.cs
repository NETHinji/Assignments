﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4

{
    class Program
    {
        static void Main(string[] args)
        {

            StudentSystem s1 = new StudentSystem(12, "Tamal", 23, 'M', new DateTime(1995, 9, 5), "23/1C Ratan ", 23.45f);
            Console.WriteLine($"Details are " + s1._RollNumber + " " + s1._Studentname + " " + s1._Age + " " + s1._Gender + " " + s1._DateOfBirth + " " + s1._Address + " " + s1._Percentage);
            Console.ReadLine();
        }
    }
}
