﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4

{
    class StudentSystem
    {
        public int _RollNumber { get; set; }
        public string _Studentname { get; set; }
        public byte _Age { get; set; }
        public char _Gender { get; set; }
        public DateTime _DateOfBirth { get; set; }
        public string _Address { get; set; }
        public float _Percentage { get; set; }
        public StudentSystem(int r, string s_name, byte a, char g, DateTime d, string addr, float p)
        {
            _RollNumber = r;
            _Studentname = s_name;
            _Age = a;
            _Gender = g;
            _DateOfBirth = d;
            _Address = addr;
            _Percentage = p;
        }
    }
}
