﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace HospitalManagementSystem
{
    /// <summary>
    /// Interaction logic for HMS1.xaml
    /// </summary>
    public partial class HMS1 : Window
    {
        int count = 0;
        public HMS1()
        {
            InitializeComponent();
        }

        private bool IsNumeric(string s)
        {
            Regex r = new Regex(@"[0-9]+$");
            return r.IsMatch(s);
        }

        private void txtUsername_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (IsNumeric(e.Text))
            {
                MessageBox.Show("!!you entered a number!!");
                e.Handled = true;
               
            }

        }

        private void txtUsername_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
            
            
            if (txtUsername.Text == "admin")
            {
                if (txtPassword.Text == "admin")
                {
                    AddPaitent addp = new AddPaitent();
                    addp.Show();

                }
                else
                {
                    MessageBox.Show("password is incorrect");
                    count++;
                }

            }
            else
            { 
                MessageBox.Show("username is incorrect");
            
                count++;
            }
            if (count > 2)
            {
                this.Close();

            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            txtUsername.Text = "";
            txtPassword.Text = "";

        }
    }
}
