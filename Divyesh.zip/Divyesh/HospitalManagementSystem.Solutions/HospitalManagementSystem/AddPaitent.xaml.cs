﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystem
{
    /// <summary>
    /// Interaction logic for AddPaitent.xaml
    /// </summary>
    public partial class AddPaitent : Window
    {
        public AddPaitent()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            int a = rnd.Next(1, 1000);
            lblPatientiddisplay.Content = a;
            HospitalManagementSystem1 hms = new HospitalManagementSystem1();

            string PatientType = (combPatientType.SelectedItem as ComboBoxItem).Content.ToString();
            hms.Adddetails(Convert.ToString(txtPatientName.Text),PatientType,a );

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            AddPaitent a = new AddPaitent();
            a.ShowDialog();

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            PatientInfo p = new PatientInfo();
            //p.ShowDialog();
            DataSet ds = new DataSet();
            using (SqlConnection sqlcon = new SqlConnection(@"Data source=ndamssql\sqlilearn; user id=sqluser;password=sqluser; Initial Catalog=Training_19Sep18_Pune;"))
            {
               // DataTable dt = null;
                sqlcon.Open();
                //MessageBox.Show("connection open");
                //string query = "select * from Shanu_Patient";
                //SqlCommand sqlcom = new SqlCommand(query,sqlcon);

                SqlDataAdapter dr = new SqlDataAdapter(@"select * from divyesh_patient", sqlcon);
                dr.Fill(ds, "divyesh_patient");
                p.dgDisplay.ItemsSource = ds.Tables["divyesh_patient"].DefaultView;
                p.ShowDialog();
            }




        }
    }
}
