﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystem
{
    /// <summary>
    /// Interaction logic for PatientInfo.xaml
    /// </summary>
    public partial class PatientInfo : Window
    {
        public PatientInfo()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();

        private void dgDisplay_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //HospitalManagementSystem1 hms = new HospitalManagementSystem1();
            // DataTable dt = hms.ViewDetails();
            using (SqlConnection sqlcon = new SqlConnection(@"Data source=ndamssql\sqlilearn; user id=sqluser;password=sqluser; Initial Catalog=Training_19Sep18_Pune;"))
            {
                DataTable dt = null;
                sqlcon.Open();
                MessageBox.Show("connection open");
                //string query = "select * from Shanu_Patient";
                //SqlCommand sqlcom = new SqlCommand(query,sqlcon);

                SqlDataAdapter dr = new SqlDataAdapter(@"select * from divyesh_patient", sqlcon);
                dr.Fill(ds, "divyesh_patient");
                dgDisplay.ItemsSource = ds.Tables["divyesh_patient"].DefaultView;

            }
           
               
           
               // MessageBox.Show("NO Information");

            
        }
    }
}
