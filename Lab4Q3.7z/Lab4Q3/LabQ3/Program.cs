﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabQ3
{
    class Program
    {
        static void Main(string[] args)
        {

            Circle c1 = new Circle();
            c1.WhoamI();
            Console.ReadKey();
        }
    }
}
