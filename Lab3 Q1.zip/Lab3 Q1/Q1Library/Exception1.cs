﻿using System;
using System.Runtime.Serialization;

namespace Q1Library
{
    [Serializable]
    internal class Exception1 : Exception
    {
        private int _Maxvalidate;
        private int _Minvalidate;

        public Exception1()
        {
        }

        public Exception1(string message) : base(message)
        {
            Console.WriteLine();
        }

        public Exception1(int maxvalidate, int minvalidate)
        {
            _Maxvalidate = maxvalidate;
            _Minvalidate = minvalidate;
            Console.WriteLine($"The number must be in between {_Maxvalidate} and {_Minvalidate}");
        }

        public Exception1(string message, Exception innerException) : base(message, innerException)
        {
        }

       
    }
}