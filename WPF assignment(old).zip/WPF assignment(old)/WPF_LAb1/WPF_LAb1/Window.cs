﻿namespace WPF_LAb1
{
    internal class Window
    {
        public string Title { get; internal set; }
        public Button Content { get; internal set; }
    }
}