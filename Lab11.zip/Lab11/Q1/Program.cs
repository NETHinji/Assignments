﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            CreditCard creditCard = new CreditCard();
            Console.WriteLine("Define the amount you want to pay");
            int amount = Convert.ToInt32(Console.ReadLine());
            creditCard.Make += creditCard.SentMessage;
            creditCard.MakePayment(amount);
            Console.ReadLine();
        }
    }
}
