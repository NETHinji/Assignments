﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculater
{
    class PerformArithmeticOperation
    {
        ArithmeticOperation A = new ArithmeticOperation();
        delegate void ArithmaticDelegate(double x, double y);
        public  void PerformArithmeticOp(double x, double y,int operation)
        {
            Console.Clear();
            switch (operation)
            {
                //Addition
                case 1:
                    {
                        ArithmaticDelegate arithmatic = (A.Add);
                        arithmatic(x, y);
                        break;
                    }
                //Subtraction
                case 2:
                    {
                        ArithmaticDelegate arithmatic = (A.Subtract);
                        arithmatic(x, y);
                        break;
                    }
                //Multiplication
                case 3:
                    {
                        ArithmaticDelegate arithmatic = (A.Multiply);
                        arithmatic(x, y);
                        break;
                    }
                //Division
                case 4:
                    {
                        ArithmaticDelegate arithmatic = (A.Divide);
                        arithmatic(x, y);
                        break;
                    }
                //Remainder
                case 5:
                    {
                        ArithmaticDelegate arithmatic = (A.FindMax);
                        arithmatic(x, y);
                        break;
                    }
                default:
                    Console.WriteLine("Exiting program");
                    break;
            }
        }
}
}
