﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_Lab8
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice:");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        Data.AddRecord();
                        break;
                    case 2:
                        Data.SearchList();
                        break;
                    case 3:
                        Data.DisplayList();
                        break;
                    case 4:
                        Data.DisplayCount();
                        break;
                    case 5:
                        Data.RemoveList(
);
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("you have entered wrong choice:");
                        break;
                }
            } while (true);
        }

        public static void PrintMenu()
        {
            Console.WriteLine("1. Add Record in Hashtable");
            Console.WriteLine("2. Search record");
            Console.WriteLine("3. Display All Records");
            Console.WriteLine("4. To display Total count of Records at any point");
            Console.WriteLine("5. Remove any particular record");
            Console.WriteLine("6. Exit");
        }
    }
}
