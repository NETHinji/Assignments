﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1Task4Library

{
    public class Employee1
    {
        int employeeId;
        string employeeName;
        string address;
        string city;
        string department;
        double salary;
        public int _EmployeeId { get; set; }
        public string _EmployeeName { get; set; }
        public string _Address { get; set; }
        public string _City { get; set; }
        public string _Department { get; set; }
        public double _Salary { get; set; }
        public void setDetails(Employee1 employee)
        {
            _EmployeeId = employee._EmployeeId;
            _EmployeeName = employee._EmployeeName;
            _Address = employee._Address;
            _City = employee._City;
            _Department = employee._Department;
            _Salary = employee._Salary;
        }
        public double getSalary()
        {

            return _Salary;
        }
    }
}
