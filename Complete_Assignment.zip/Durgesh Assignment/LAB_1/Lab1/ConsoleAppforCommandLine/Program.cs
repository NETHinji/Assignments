﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            a = Convert.ToInt32(args[0]);
            switch (a)
            {
                case 1:
                    Console.WriteLine("1 is choice");
                    break;
                case 2:
                    Console.WriteLine("2 is choice");
                    break;
                case 3:
                    Console.WriteLine("3 is choice");
                    break;
                case 4:
                    Console.WriteLine("4 is choice");
                    break;
                case 5:
                    Console.WriteLine("5 is choice");
                    break;
                default:
                    Console.WriteLine("Wrong choice");
                    break;
            }
            Console.ReadLine();
        }
    }
}
