﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Lab13
{
    [Serializable]
    class Program
    {
        static List<Contact> contacts = new List<Contact>();
        static void Main(string[] args)
        {
            Contact contact = new Contact();
            Console.WriteLine("Enter the contact number:");
            contact.ContactNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name:");
            contact.ContactName = Console.ReadLine();
            Console.WriteLine("Enter cell no");
            contact.CellNo = Console.ReadLine();
            AddContact(contact);
            SerializeData(contacts);
            DeSerializeData(contacts);
           
        }
        public static void AddContact(Contact contact)
        {
            contacts.Add(contact);
        }
        private static void SerializeData(List<Contact> e1)
        {
            try
            {
                using (Stream stream = File.Open("D:\\File1.txt", FileMode.Create))
                {
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(stream,contacts);
                }
            }
            catch (IOException)
            {
            }
        }
        private static void DeSerializeData(List<Contact> contacts)
        {
            Stream stream = new FileStream(@"D:\\File1.txt", FileMode.Open, FileAccess.ReadWrite);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            var c1 = (List<Contact>)binaryFormatter.Deserialize(stream);
            stream.Close();
            foreach (Contact contact in c1)
            {
                Console.WriteLine("{0}, {1}, {2}",
                   contact.CellNo,contact.ContactName,contact.ContactNo);
            }
        }
       


    }
}
