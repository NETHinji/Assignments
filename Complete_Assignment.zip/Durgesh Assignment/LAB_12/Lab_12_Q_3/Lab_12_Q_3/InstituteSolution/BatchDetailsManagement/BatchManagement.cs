﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BatchDetailsManagement
{
    class BatchManagement
    {
        
        private static string DirectoryForFile = @"c:\\Academy";

        static void Main(string[] args)
        {
            int choice;

            do
            {
                Console.WriteLine("===============================================================");
                Console.WriteLine("Menu");
                Console.WriteLine("1.Create directory and files");
                Console.WriteLine("2.Insert batch details to file");
                Console.WriteLine("3.Make backup copy");
                Console.WriteLine("4.Display file contents");
                Console.WriteLine("5.Exit");
                Console.WriteLine("===============================================================");
                Console.WriteLine("\nEnter choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        CreateFolder();
                        break;
                    case 2:
                        AddBatchDetails();
                        break;
                    case 3:
                        CreateBackup(DirectoryForFile,@"D:\Academy");
                        break;
                    case 4:
                        DisplayFileContents();
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("\nWrong Value Selected");
                        break;
                }
            } while (choice != -1);
        }

        private static void CreateBackup(string root,string dest)
        {
            try
            {
                foreach (var directory in Directory.GetDirectories(root))
                {
                    string dirName = Path.GetFileName(directory);
                    if (!Directory.Exists(Path.Combine(dest, dirName)))
                    {
                        Directory.CreateDirectory(Path.Combine(dest, dirName));
                    }
                    CreateBackup(directory, Path.Combine(dest, dirName));
                }

                foreach (var file in Directory.GetFiles(root))
                {
                    File.Copy(file, Path.Combine(dest, Path.GetFileName(file)));
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DisplayFileContents()
        {
            try
            {
                string[] Filepaths = Directory.GetFiles(DirectoryForFile, "*.txt", SearchOption.AllDirectories);
                
                if(Filepaths.Length==0)
                {
                    Console.WriteLine("\nNo files exist");
                }
                else
                {
                    string temp;
                    for(int i=0;i<Filepaths.Length;i++)
                    {
                        Console.WriteLine("\nContent of file: " + Filepaths[i]);
                        StreamReader sr1 = File.OpenText(Filepaths[i]);
                        temp = sr1.ReadToEnd();
                        Console.WriteLine(temp);
                        sr1.Close();
                    }
                }
                    
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddBatchDetails()
        {
            try
            {
                Console.WriteLine("\nInsert Filename you wish to add details to: ");
                string SearchName = Console.ReadLine();
                string[] Filepaths = Directory.GetFiles(DirectoryForFile, "*.txt", SearchOption.AllDirectories);
                int count = 5;
                for (int i = 0; i < Filepaths.Length; i++)
                {
                    if (Filepaths[i].Contains(SearchName))
                    {
                        count = i;
                    }

                }
                if (count == 5)
                {
                    Console.WriteLine("\nFile does not exist");
                }
                
                else
                {
                    
                    StreamWriter sw1 = File.AppendText(Filepaths[count]);
                    Console.WriteLine("\nInsert content:");
                    string Content = Console.ReadLine();
                    sw1.WriteLine(Content);
                    sw1.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void CreateFolder()
        {
            try
            {
                Console.WriteLine("\nEnter Directory Name:");
                string RootFolderName = Console.ReadLine();
                //string RootDirectory = Path.Combine(@"\InstituteSolution", RootFolderName);
                string RootDirectory = @"c:\\" + RootFolderName;

                if (!Directory.Exists(RootDirectory)&&RootFolderName=="Academy")
                {
                    Directory.CreateDirectory(RootDirectory);
                    //Console.WriteLine("Root Directory Created");
                    //DirectoryForFile = RootDirectory;
                    for (int i = 1; i <= 4; i++)
                    {
                        Console.WriteLine("\nEnter Name of Subfolder " + i + ":");
                        string SubFolderName = Console.ReadLine();
                        string SubDirectory = RootDirectory + @"\" + SubFolderName;
                        if (!Directory.Exists(SubDirectory))
                        {
                            Directory.CreateDirectory(SubDirectory);

                            Console.WriteLine("\nInsert File Name for this directory:");
                            string FileName = Console.ReadLine();
                            string FileDirectory = SubDirectory + @"\" + FileName + ".txt";

                            if (!Directory.Exists(FileDirectory))
                            {
                                FileStream fs1 = new FileStream(FileDirectory, FileMode.Create);
                                fs1.Close();
                            }
                            else
                                Console.WriteLine("\nFile Already Exists");

                        }
                        else
                            Console.WriteLine("\nSubdirectory Already Exists");

                    }

                }
                else
                    Console.WriteLine("\nDirectory Already Exists or Directory Name is not Academy");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



    }
}

