﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    class City
    {

    }
    class Program
    {
        static void Main(string[] args)
        {
            string[] city = new string[3];
            Console.WriteLine("Enter 3 Cities");

            for (int i = 0; i < city.Length; i++)
                city[i] = Console.ReadLine();

            Console.WriteLine("Your entered cities are");

            foreach (string c in city)
            {
                Console.WriteLine(c);

            }
            Console.ReadLine();

        }
    }
}
