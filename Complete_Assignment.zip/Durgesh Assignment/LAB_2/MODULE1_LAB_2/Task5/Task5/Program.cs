﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2_TASK5
{
  
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            //Declaring multi dimensional array
            string[,] BooksDetails = new string[2,4];
            for (i = 0; i < 1; i++)
            {
                Console.Write("Enter columns Name:");
                for (j = 0; j < 4; j++)
                {
                    BooksDetails[i, j] = Console.ReadLine();
                }
            }
            Console.Write("Enter Book Details:");
            for (i = 1; i < 2; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    BooksDetails[i, j] = Console.ReadLine();
                }
            }

            for (i = 0; i < 2; i++)
            {
               
                for (j = 0; j < 4; j++)
                {
                   Console.Write("   "+BooksDetails[i, j]);
                }
                Console.WriteLine();
            }


        }
    }
}
