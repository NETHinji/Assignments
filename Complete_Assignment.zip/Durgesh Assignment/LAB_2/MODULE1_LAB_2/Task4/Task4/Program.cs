﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductInfo
{
    public class ProductDemo
    {
        static int productID;
        static string productName;
        static double price;
        double quantity;
        double amountPayable;
        public void Input()
        {
            Console.WriteLine("Enter Product ID");
            productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter The Product Name");
            productName = Console.ReadLine();
            Console.WriteLine("Enter Price");
            price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Quantity");
            quantity = Convert.ToInt32(Console.ReadLine());
            amountPayable = quantity * price;
        }
        public void Display()
        {
            object objProductID = productID;
            object objProductName = productName;
            object objPrice = price;
            object objQuantity = quantity;
            Console.WriteLine("Product ID is : " + (int)objProductID);
            Console.WriteLine("ProductDemo Name is : " + (string)objProductName);
            Console.WriteLine("Price of the Product is : " + (double)objPrice);
            Console.WriteLine("Quantity of total Product is : " + (double)objQuantity);
            Console.WriteLine("Total Payable ammount is : " + amountPayable);
        }

    }
    class Output
    {

        public static void Main(string[] args)
        {
            ProductDemo pd1 = new ProductDemo();
            pd1.Input();
            pd1.Display();
        }
    }
}
