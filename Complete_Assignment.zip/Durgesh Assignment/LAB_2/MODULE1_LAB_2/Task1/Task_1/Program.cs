﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB1_1
{
    struct User
    {
        int number;
        public int Square(int n)
        {
            number = n * n;
            return number;
        }
        public int Cube(int n)
        {
            number = n * n * n;
            return number;
        }
    }
    struct MainUser
    {
        public static void Main()
        {
            User u1 = new User();
            Console.WriteLine("Enter the choice 1.Square 2.Cube");
            int ch = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number");
            int q = Convert.ToInt32(Console.ReadLine());

            switch (ch)
            {
                case 1:
                    Console.WriteLine($"Square of {q} :" + u1.Square(q));
                    break;
                case 2:
                    Console.WriteLine($"Cube of {q} :" + u1.Cube(q));
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
        }


    }
}
