﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1_Lab2_Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            int[,] arr1 = new int[5, 6];

            Console.Write("\n\nRead a 2D array of size 5x6 and print the matrix :\n");
            Console.Write("------------------------------------------------------\n");


            /* Stored values into the array*/
            Console.Write("Input elements in the matrix :\n");
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 6; j++)
                {
                    Console.Write("element - [{0},{1}] : ", i, j);
                    arr1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("\nThe matrix is : \n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 6; j++)
                    Console.Write("{0}\t", arr1[i, j]);
            }
            Console.Write("\n\n");
        }
    }
}

