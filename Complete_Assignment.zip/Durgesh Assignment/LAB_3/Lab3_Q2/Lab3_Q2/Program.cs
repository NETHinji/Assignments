﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Q2
{
    public class Bird
    {


        private string _Name;
        private double _MaxHeight;
        public Bird() //Default Constructor
        {
            this._Name = "Mountain Eagle";
            this._MaxHeight = 500;
            //
            // TODO: Add constructor logic here
            //
        }
       public Bird(string birdName, double maxHeightt) //Overloaded Constructor
        {
            this._Name = birdName;
            this._MaxHeight = maxHeightt;
        }
        public void Fly()
        {

            Console.WriteLine(_Name + " is flying at altitude " + _MaxHeight);
        }
        public void Fly(double AtHeight)
        {
            if (AtHeight <= this._MaxHeight)
                Console.WriteLine(this._Name + " flying at " + AtHeight.ToString());
            else
                Console.WriteLine(this._Name + "cannot fly at this height");


           
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Bird b = new Bird("Eagle", double.Parse("200"));
            b.Fly();
            b.Fly(double.Parse("300"));
            Console.ReadKey();
        }
    }
}

