﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Supplier;


namespace Supplier.DataAccessLayer
{
    public class SupplierDAL
    {
        

        public static void DisplayDetails(Supplier1 supplier)
        {
            Console.WriteLine("Supplier Details are:");
            Console.WriteLine("Supplier Id:" + supplier.SupplierId);
            Console.WriteLine("Supplier Id:" + supplier.SupplierName);
            Console.WriteLine("Supplier Id:" + supplier.City);
            Console.WriteLine("Supplier Id:" + supplier.PhoneNo);
            Console.WriteLine("Supplier Id:" + supplier.Email);
        }

    }
}
