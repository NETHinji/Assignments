﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ABC1Corp.Exceptions
{
    public class InvalidCreditLimitException : ApplicationException
    {
        public InvalidCreditLimitException(string name) : base(string.Format("invalid credit limit\t" + name))
        {

        }

        public InvalidCreditLimitException(string message, System.Exception innerException) : base(message, innerException)
        {



        }

        protected InvalidCreditLimitException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
