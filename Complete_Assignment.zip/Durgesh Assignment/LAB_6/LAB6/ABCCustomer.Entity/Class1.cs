﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCCustomer.Entity
{
    public class Customer
    {

        private int _CustomerId;
        private string _CustomerName;
            private string _Address;
            private string _City;
            private string _Phone;
            private double _CreditLimit;

        public Customer()
        {
            _CustomerId =0;
            _CustomerName = string.Empty;
            _Address = string.Empty;
            _City = string.Empty;
            _Phone = string.Empty;
            _CreditLimit = 0.0;

        }

        public Customer(int CustomerId, string CustomerName, string Address, string City, string Phone, double CreditLimit)
        {
            _CustomerId = CustomerId;
            _CustomerName = CustomerName;
            _Address = Address;
            _City = City;
            _Phone = Phone;
            _CreditLimit = CreditLimit;
        }

        public int CustomerId { get; set; }
        public string CustomerName { get; set; }

        public string Address { get; set; }
        public string City { get; set; }
        public string Phone { get; set; }
        public double CreditLimit { get; set; }


    }
}
