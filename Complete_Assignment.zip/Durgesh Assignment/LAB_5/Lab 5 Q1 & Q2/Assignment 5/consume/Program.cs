﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;
namespace consume
{
    class Program
    {
        static void Main(string[] args)
        {
            ICICI icici = new Banking.ICICI();

            int ch=0;

            Console.WriteLine("Menu:");

            Console.WriteLine("1.ICICI");
            Console.WriteLine(" 2.HSBC");
            Console.WriteLine(" 3.Interest Calculator");
            Console.WriteLine("Enter Your Choice:");

            ch = Convert.ToInt32(Console.ReadLine());

            HSBC hsbc = new Banking.HSBC();
            
            switch (ch) {
                case 1: Console.WriteLine("You Selected ICICI");
                   
                    Console.WriteLine("Bank Account Type: {0}", BankAccountTypeEnum.Saving);
                    icici.Balance = 50000;
                    icici.Withdraw(30000);
                  
                    

                    break;

                case 2:
                    Console.WriteLine("You Selected HSBC");
                   

                    hsbc.Balance = 50000;
                    hsbc.Withdraw(2000);
                    

                    break;


                case 3:Console.WriteLine("Interest Calculator");
                    Console.WriteLine("For ICICI");
                    icici.CalculateInterest();

                    Console.WriteLine(" ");
                    Console.WriteLine(" ");

                    Console.WriteLine("For ICICI");
                    hsbc.CalculateInterest();

                    break;
                default : Console.WriteLine("Enter Right Choice");

                
                    break;

            }

           


         

            hsbc.Balance = 50000;
            hsbc.Withdraw(2000);

            hsbc.CalculateInterest();






            Console.ReadLine();

        }
    }
}
