﻿namespace Banking
{
    public enum BankAccountTypeEnum
    {
        Current = 1,
        Saving = 2
    }
}