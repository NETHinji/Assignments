﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            FileDownloader fd = new FileDownloader("http://www.microsoft.com./vstudio/expressv10.zip", "d:\\setups");
            fd.OnDownLoadComplete += fd_DownLoadComplete;
            fd.DownLoadResource();
            Console.ReadKey();
        }
        static void fd_DownLoadComplete(int perc)
        {
            Console.SetCursorPosition(10, 10);
            Console.WriteLine("Downloading {0} percent complete", perc);
        }
    }
}
