﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    public delegate void DownLoadCompleteHandler(int perc);
    class FileDownloader
    {
        public  string resourceUrl;
        public  string resourceSavePath;

        public event DownLoadCompleteHandler OnDownLoadComplete;

        public FileDownloader(string url,string savepath)
        {
            this.resourceUrl = url;
            this.resourceSavePath = savepath;
        }
        public void DownLoadResource()
        {
            for(int i = 0; i <=4; i++)
            {
                for (int j = 1; j <= 10000; j++)
                    OnDownLoadComplete(i * 25);
            }
        }
        public  void OnDownLoadComplete1()
        {
            if (OnDownLoadComplete == null)
                OnDownLoadComplete(0);
        }
    }
}
