﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BusinessLayer;
using DataAccesssLayer;

using Entity;
using Exceptions;


namespace ProductUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
        }

        private void BtnAddCategory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product
                {
                    ProductName = txtPName.Text,
                    Description = txtDescp.Text,
                    UnitPrice = decimal.Parse(txtUP.Text),
                    Stock = int.Parse(txtStock.Text),
                    Category = int.Parse(cmbCategories.SelectedValue.ToString())
                };
                MyProductBL pb = new MyProductBL();
                int pid = pb.AddProduct(p);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", pid),
                    "Product Management System");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}
