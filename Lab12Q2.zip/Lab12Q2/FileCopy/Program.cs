﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string SourceFileName, DestinationFile;
                Console.WriteLine("Enter the name of file");
                SourceFileName = Console.ReadLine();
                Console.WriteLine("Enter the name of file");
                DestinationFile = Console.ReadLine();

                File.Copy(SourceFileName, DestinationFile);
                Console.WriteLine(File.ReadAllText(SourceFileName));
                Console.WriteLine(File.ReadAllText(DestinationFile));

            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine("Could not found file");
            }
            catch (FileLoadException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }



        }
    }
}
