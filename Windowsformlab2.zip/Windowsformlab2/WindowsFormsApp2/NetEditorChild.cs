﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class NetEditorChild : Form
    {
        int flag = 0;
        public NetEditorChild()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NetEditorChild nec = new NetEditorChild();
            nec.Text = "New Document";
           // nec.MdiParent = this;
            nec.Show();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.Filter = "TextFiles|*.txt|XML Files|*.xml";
            if (opd.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(File.OpenRead(opd.FileName));
                NetEditorChild nec = new NetEditorChild();
                nec.Text = opd.FileName;
                nec.textBox1.Text = sr.ReadToEnd();
                sr.Close();
                //nec.MdiParent = this;
                nec.Show();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
                this.ActiveMdiChild.Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                sfd.FilterIndex = 2;

                if (sfd.ShowDialog() == DialogResult.OK && flag==0)
                {
                    File.WriteAllText(sfd.FileName, textBox1.Text);
                    flag = 1;
                }
            }
        }
    }
}
