﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking
{
   public class HSBC:BankAccount
    {
        public override void CalculateInterest()
        {
            double Interest;
            double Principal;
            double Duration;
            double ROI = 5;
            Console.WriteLine("Interest calculator.");
            Console.WriteLine("Enter Principal Amount");
            Principal = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Duration");
            Duration = Convert.ToDouble(Console.ReadLine());

            Interest = (Principal * Duration * ROI) / 100;
            Console.WriteLine("You will get {0} After {0} years", Interest, Duration);
        }

        public override bool Withdraw(double amount)
        {
            Console.WriteLine("You Entered Amount {0} for Withdrawal. ", amount);
            if (amount > Balance)
            {

                Console.WriteLine("Balance is Low! You Cannot Withdraw{0} Rupees", amount);

            }
            else
            {
                Console.WriteLine("Withdraw Successfull");
                Balance = Balance - amount;

                Console.WriteLine(" Remaining Balance in Your Account is {0}", Balance);
            }

            return true;
        }
    }
}
