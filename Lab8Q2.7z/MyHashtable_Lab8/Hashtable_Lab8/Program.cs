﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_Lab8
{
    class Program
    {

        static Hashtable GetHashtable()
        {
           
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);                                      // Create and return new Hashtable.
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }
        public Hashtable _hashtable;
        static void Main(string[] args)
        {
            Program ob = new Program();
            ob._hashtable = GetHashtable();
            // To check if the Hashtable contains perimeter key.
            Console.WriteLine(ob._hashtable.ContainsKey("Perimeter"));              


            // To check whether the ContainsKey and Contains method work in the same way
            // ... It works in the same way.
            Console.WriteLine(ob._hashtable.Contains("Perimeter"));


            // To get the value of Area using indexer.
            int value = ob["Area"];


            // To print the value of Area.
            Console.WriteLine(value);                                           


            //To remove the entry of Mortgage
           if (ob._hashtable.ContainsKey("Mortgage"))
            {
                ob._hashtable.Remove("Mortgage");
                Console.WriteLine("Mortgage removed successfully");
            }
           else
            {
                Console.WriteLine("Mortgage is not present");
            }
        }
        public int this[string index]
        {
            get
            {
                if (_hashtable.Contains(index))
                {
                    return (int)_hashtable[index];
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                _hashtable[index] = value;
            }
        }
    }
}