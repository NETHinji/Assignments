﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier

{
    public class Supplier1
    {
        private int _SupplierId;

        public int SupplierId
        {
            get { return _SupplierId; }
            set { _SupplierId = value; }
        }

        private string _SupplierName;

        public string SupplierName
        {
            get { return _SupplierName; }
            set { _SupplierName = value; }
        }

        private string _City;

        public string City
        {
            get { return _City; }
            set { _City = value; }
        }

        private int  _PhoneNo;

        public int PhoneNo
        {
            get { return _PhoneNo; }
            set { _PhoneNo = value; }
        }

        private string _Email;

        public string Email
        {
            get { return _Email; }
            set { _Email = value; }
        }







    }
}



