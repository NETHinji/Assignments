﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Supplier.DataAccessLayer;

namespace Supplier.BusinessLogic
{
    public class SupplierBL
    {
       private static  bool IsValidate(Supplier1 supplier)
        {
            bool Isvalid = false;

            if (supplier.SupplierName == null) return Isvalid;
            else if (supplier.City == null) return Isvalid;
            else if (supplier.PhoneNo<=9999999999 && supplier.PhoneNo>= 1000000000) return Isvalid;
            else if (!supplier.Email.Contains('@') && !supplier.Email.Contains(".com")) return Isvalid;
            else Isvalid = true;
            return Isvalid;

        }

       public  static bool  IsValidSupplier(Supplier1 supplier)
        {
            bool Isvalid = false;

            Isvalid = IsValidate(supplier);

            if (Isvalid)
            {
                Console.WriteLine("Valid Customer");
               
                SupplierDAL.DisplayDetails(supplier);
                return Isvalid;
            }
            else
            {
                Console.WriteLine("Not a valid Customer");
                return Isvalid;
            }

          
        }

    }
}
