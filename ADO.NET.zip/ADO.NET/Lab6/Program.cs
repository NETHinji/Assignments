﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>
            {
                new Employee(){EmployeeID=1001,FirstName="Malcolm",LastName="Daruwalla",Title="Manager",DOB= new DateTime(1994,11,16), DOJ=new DateTime(2011,6,8),City="Mumbai"},
                new Employee(){EmployeeID=1002,FirstName="Asdin",LastName="Dhalla",Title="AsstManager",DOB=new DateTime(1984,8,20),DOJ=new DateTime(2012,7,7),City="Mumbai"},
                new Employee(){EmployeeID=1003,FirstName="Madhavi",LastName="Oza",Title="Consultant",DOB=new DateTime(1987,11,14),DOJ=new DateTime(2015,4,12),City="Pune" },
               new Employee(){EmployeeID=1004,FirstName="Saba",LastName="Shaikh",Title="SE",DOB=new DateTime(1990,6,3),DOJ=new DateTime(2016,2,2),City="Pune" },
               new Employee(){EmployeeID=1005,FirstName="Nazia",LastName="Shaikh",Title="SE",DOB=new DateTime(1991,3,8),DOJ=new DateTime(2016,2,2),City="Mumbai" },
               new Employee(){EmployeeID=1006,FirstName="Amit",LastName="Pathak",Title="Consultant",DOB=new DateTime(1989,11,7),DOJ=new DateTime(2014,8,8),City="Chennai" },
               new Employee(){EmployeeID=1007,FirstName="Vijay",LastName="Natrajan",Title="Consultant",DOB=new DateTime(1989,12,2),DOJ=new DateTime(2015,6,1),City="Mumbai" },
              new Employee(){EmployeeID=1008,FirstName="Rahul",LastName="Dubey",Title="Associate",DOB=new DateTime(1993,11,11),DOJ=new DateTime(2014,11,6),City="Chennai" },
           new Employee(){EmployeeID=1009,FirstName="Suresh",LastName="Mistry",Title="Associate",DOB=new DateTime(1992,8,12),DOJ=new DateTime(2014,12,3),City="Chennai" },
              new Employee(){EmployeeID=1010,FirstName="Sumit",LastName="Shah",Title="Manager",DOB=new DateTime(1991,4,12),DOJ=new DateTime(2016,2,1),City="Pune" },
            };
           IEnumerable<Employee>c = from m in employees select m;
            foreach(Employee e in c)
            {
                Console.WriteLine("Employee ID: "+e.EmployeeID+"\nFirstName: "+e.FirstName+"\nLastName: "+e.LastName+ "\nTitle: "+e.Title+"\nDate of birth: "+e.DOB+"\nDate of joining: "+e.DOJ+"\nCity: "+e.City );
            }
            Console.WriteLine();
            c = from m in employees where m.City != "Mumbai" select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c= from m in employees where m.Title == "AsstManager" select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c = from m in employees where m.LastName.StartsWith("S") select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c = from m in employees where m.DOJ.CompareTo(new DateTime(2015, 1, 1)) <= 0 select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c = from m in employees where m.DOB.CompareTo(new DateTime(1990, 1, 1)) >= 0 select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c = from m in employees where m.Title == "Associate" || m.Title == "Consultant" select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            int c1 = (from m in employees select m).Count();
            Console.WriteLine("Number of emplyees :" + c1);
            Console.WriteLine();
            c = from m in employees where m.City == "Chennai" select m;
            foreach (Employee e in c)
            {
                Console.WriteLine("Employee ID: " + e.EmployeeID + "\nFirstName: " + e.FirstName + "\nLastName: " + e.LastName + "\nTitle: " + e.Title + "\nDate of birth: " + e.DOB + "\nDate of joining: " + e.DOJ + "\nCity: " + e.City);
            }
            Console.WriteLine();
            c1 = (from m in c select m.EmployeeID).Max();
            Console.WriteLine("Maximum id is :" + c1);
            Console.WriteLine();
            c1 = (from m in employees where m.DOJ.CompareTo(new DateTime(2015, 1, 1)) >= 0 select m).Count();
            Console.WriteLine("Number of employees joined after 1/1/2015 is " + c1);
            Console.WriteLine();
            c1 = (from m in employees where m.Title != "Associate" select m).Count();
            Console.WriteLine("Number of employees not associate :" + c1);
            Console.WriteLine();
            var a = from m in employees group m by m.City into g select new { CityName = g.Key, Number_of_employess = g.Count() };
            foreach(var a1 in a)
            {
                Console.WriteLine(a1.CityName+" "+a1.Number_of_employess);
            }
            Console.WriteLine();
            var a2 = from m in employees group m by m.Title into g select new { Title = g.Key, Number_of_employees = g.Count() };
            foreach (var a1 in a2)
            {
                Console.WriteLine(a1.Title+" "+a1.Number_of_employees);
            }
            Console.WriteLine();
            var a3 = (from m in employees where m.DOB.CompareTo((from n in employees select n.DOB).Min())==0 select m).Count();
            Console.WriteLine(a3);
            Console.ReadLine();
        }
    }
}
