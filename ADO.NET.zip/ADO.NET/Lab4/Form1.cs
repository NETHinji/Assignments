﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class SupplierForm : Form
    {
        public SupplierForm()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        private void SupplierForm_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=mdssql\sqlilearn;initial catalog=Training_19Sep18_Pune;user id=sqluser;password=sqluser");
            con.Open();
            ds = new DataSet();
            da = new SqlDataAdapter("select * from supplier", con);
            da.Fill(ds, "Supplier");
            dataGridView1.DataSource = ds.Tables["supplier"].DefaultView;
        }

        private void btnsortcity_Click(object sender, EventArgs e)
        {
            ds.Tables["supplier"].DefaultView.RowFilter = "city like'" + txtcity.Text +"'";          
        }

        private void btnsortname_Click(object sender, EventArgs e)
        {
            ds.Tables["supplier"].DefaultView.RowFilter = "name like'" + txtname.Text + "'";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(ds.Tables["supplier"]);
                MessageBox.Show("Changes saved");
            }
            catch (SqlException sqlex)
            {

                MessageBox.Show(sqlex.Message);
            }
        }
    }
}
