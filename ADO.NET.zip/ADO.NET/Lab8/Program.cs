﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_19Sep18_PuneEntities p = new Training_19Sep18_PuneEntities();
            Employee_Lab8 e = new Employee_Lab8() { ID = 2012, Name = "Employee", DOB = new DateTime(1995, 3, 4), DOJ = new DateTime(2018, 9, 19), Designation = "Analyst", Salary = 17000 };
            p.Employee_Lab8.Add(e);
            p.SaveChanges();
            Console.WriteLine("Enter the id to update");
            int b = Convert.ToInt32(Console.ReadLine());
            Employee_Lab8 lab = (from m in p.Employee_Lab8.Where(m => m.ID == b) select m).FirstOrDefault();
            if (lab != null)
            {
                lab.Name = "Gopal";
                lab.DOB = new DateTime(1994, 4, 5);
                lab.Designation = "Associate";
                lab.Salary = 40000;
                p.SaveChanges();
                Console.WriteLine("Data updated successfully");
            }
            else
            {
                Console.WriteLine("Cannot update data not available");
            }
            Console.WriteLine("Enter the id to delete");
             b = Convert.ToInt32(Console.ReadLine());
            Employee_Lab8 lab1 = (from m in p.Employee_Lab8.Where(m => m.ID == b) select m).FirstOrDefault();
            if (lab != null)
            {
                p.Employee_Lab8.Remove(lab1);
                p.SaveChanges();
                Console.WriteLine("Record deleted");
            }
            else
            {
                Console.WriteLine("Cannot delete data not available");
            }


        }
    }
}
