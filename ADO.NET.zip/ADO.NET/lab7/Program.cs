﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_19Sep18_PuneEntities p = new Training_19Sep18_PuneEntities();
            Student_master student = new Student_master();
            var query = from m in p.Student_master where m.Address != null select m;
            foreach(Student_master s in query)
            {
                Console.WriteLine("Student Code: " + s.Stud_Code + "Student Name:" + s.Stud_Name + "Student department code: " + s.Dept_Code + "Student date of birth: " + s.Stud_Dob + "Student Address: " + s.Address);
            }
            Console.WriteLine();
            query = from m in p.Student_master select m;
            foreach(Student_master s in query)
            {
                Console.WriteLine("Student name :" + s.Stud_Name + " Student department : " + s.Dept_Code + " Student date of birth :" + s.Stud_Dob);
            }
            Console.WriteLine();
            int i = (from m in p.Student_master where m.Address == "Bangalore" select m).Count();
            Console.WriteLine("No of Student belonging to bangalore :" + i);
            Console.WriteLine();
            var query1 = from n in p.Staff_Master where n.Salary > ((from m in p.Staff_Master select m.Salary).Average()) select n;
            foreach(Staff_Master s in query1)
            {
                Console.WriteLine("Staff_Code :" + s.Staff_Code + "Staff_Name :" + s.Staff_Name + "Desc_Code :" + s.Des_Code + "Dept_Code :" + s.Dept_Code + "Staff_Dob :" + s.Staff_dob + " HireDate :" + s.Hiredate + " Manager code :" + s.Mgr_code + " Salary :" + s.Salary + " Address :" + s.Address);
            }
            Console.ReadLine();
        }
    }
}
