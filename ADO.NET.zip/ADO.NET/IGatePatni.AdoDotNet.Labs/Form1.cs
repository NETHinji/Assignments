﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IGatePatni.AdoDotNet.Labs
{
    public partial class DataSetAdapter_Demo : Form
    {
        public DataSetAdapter_Demo()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;

        private void DataSetAdapter_Demo_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=mdssql\sqlilearn;initial catalog=Training_19Sep18_Pune;user id=sqluser;password=sqluser");
            con.Open();
            da = new SqlDataAdapter("select * from application users", con);
            SqlCommandBuilder bld = new SqlCommandBuilder(da);
            grdUsers.DataSource = ds.Tables["applicationusers"];

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            ds.Tables["applcationusers"].RejectChanges();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(ds.Tables["applcationusers"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException sqlex)
            {

                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnstates_Click(object sender, EventArgs e)
        {
            foreach(DataRow drow in ds.Tables["applicationusers"].Rows)
            {
                if (drow.RowState == DataRowState.Deleted)
                    MessageBox.Show(drow["username", DataRowVersion.Original].ToString() + "deleted");
                else
                    MessageBox.Show(drow["username"].ToString() + " " + drow.RowState.ToString());
            }
        }
    }
}
