﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = null;

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=mdssql\sqlilearn;initial catalog=Training_19Sep18_Pune;user id=sqluser;password=sqluser");
            con.Open();
        }

        private void btnquery_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader dreader = null;
                SqlCommand cmd = new SqlCommand("GetEmployeeById", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);
                cmd.Parameters["@eno"].Value = int.Parse(txtempno.Text);
                dreader = cmd.ExecuteReader();
                if (dreader.Read())
                {
                    txtempname.Text = dreader["empname"].ToString();
                    txtsalary.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        rdpayroll.Checked = true;
                    else
                        rdconsultant.Checked = true;
                }
                else
                {
                    btnnew_Click(btnnew, e);
                    MessageBox.Show("No such emplyoee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {

                MessageBox.Show(sqlex.Message);
            }
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtempname.Text = "";
            txtempno.Text = "";
            txtsalary.Text = "";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            
            try
            {
                int id = 0;
                SqlCommand cmd = new SqlCommand("AddEmployee", con);
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@ename", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);
                cmd.Parameters["@eno"].Value = txtempno.Text;
                cmd.Parameters["@eno"].Direction = ParameterDirection.Output;
                cmd.Parameters["@ename"].Value = txtempname.Text;
                cmd.Parameters["@esal"].Value = txtsalary.Text;
                cmd.Parameters["@etyp"].Value = rdpayroll.Checked == true ? "P" : "C";
                SqlDataReader dreader = cmd.ExecuteReader();
                MessageBox.Show($"The id is {dreader.GetInt32(1).ToString()}");
                
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex) 
            {

                MessageBox.Show(sqlex.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                if ((MessageBox.Show("Do you want to delete this record?", "DeleteRecord", MessageBoxButtons.YesNo) == DialogResult.Yes))
                {
                    SqlCommand cmd = new SqlCommand("delete from employee", con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (SqlException sqlex)
            {

                MessageBox.Show(sqlex.Message);
            }
        }
    }
}
