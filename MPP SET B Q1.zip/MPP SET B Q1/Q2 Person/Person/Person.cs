﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    class Person
    {

        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        private string FirstName;
        private string LastName;

        public override string ToString() => $"{FirstName} {LastName}".Trim();
        public void DisplayName() => Console.WriteLine(ToString());
        public static void Main(string[] args)
        {
            Person p = new Person("Bhakti", "Patil");
            Console.WriteLine(p);
            p.DisplayName();
            Console.ReadKey();
        }
    }
}
