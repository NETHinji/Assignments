﻿using System;
using System.Runtime.Serialization;

namespace DimpleEnterprise.Exceptions
{
    [Serializable]
    public class DimpleEnterpriseException : Exception
    {
        public DimpleEnterpriseException()
        {
        }

        public DimpleEnterpriseException(string message) : base(message)
        {
        }

        public DimpleEnterpriseException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DimpleEnterpriseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}