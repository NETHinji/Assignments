﻿namespace DimpleEnterprise.Entities
{
    public class Customer
    {
        public Customer()
        {
            CustomerID = "C1234";
            CustomerName = "Bhakti";
            Address = "Flat No. 30, Mayur Apartment";
            City = "Chennai";
            Contact = "9134567467";
            Email = "bhakti.patil@gmail.com";
        }
        public string City { get; set; }
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
    }
}
