﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DimpleEnterprise.Entities;
using DimpleEnterprise.Exceptions;
using DimpleEnterprise.DataAccessLayer;

namespace DimpleEnterprise.BusinessLayer
{
    public class CustomerBL
    {
        private static bool ValidateGuest(Customer customer)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                bool validCustomer = true;
                //Validation of all fields are mandetary
                if (customer.CustomerName == string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer Name Required");

                }
                if (customer.CustomerID == string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer ID Required");

                }
                if (customer.Address == string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer Address Required");

                }
                if (customer.City == null)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer City Required");

                }
                if (customer.Contact == string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer Contact Required");

                }
                if (customer.Email == string.Empty)
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Customer Email Required");

                }
                //validation of  Customer ID should be of 5 digits and beginning with char 'c'
                if (customer.CustomerID.Length < 5 && customer.CustomerID[0] == 'C')
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Invalid Guest ID");

                }
                // validation of contact no
                if (customer.Contact.Length < 10 && (customer.Contact[0] == '9' || customer.Contact[0] == '8'))
                {
                    validCustomer = false;
                    sb.Append(Environment.NewLine + "Required 10 Digit Contact Number Starting With 9 or 8");
                }
                // string stringAfterChar = customer.Email.Substring(customer.IndexOf("@") + 2);

                if (validCustomer == false)
                    throw new DimpleEnterpriseException(sb.ToString());
                return validCustomer;
            }
            catch (Exception )
            {
                throw;
            }
        }

        public static bool AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                if (ValidateGuest(newCustomer))
                {
                    CustomerDAL customerDAL = new CustomerDAL();
                    customerAdded = customerDAL.AddCustomerDAL(newCustomer);
                }
            }
            catch (DimpleEnterpriseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return customerAdded;
        }

        public static List<Customer> GetAllCustomersBL()
        {
            List<Customer> customerList = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                customerList = customerDAL.GetAllCustomersDAL();
            }
            catch (DimpleEnterpriseException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static Customer SearchCustomerBL(string searchCity)
        {
            Customer searchCustomer = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();
                searchCustomer = customerDAL.SearchCustomerDAL(searchCity);
            }
            catch (DimpleEnterpriseException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCustomer;

        }
    }
}
