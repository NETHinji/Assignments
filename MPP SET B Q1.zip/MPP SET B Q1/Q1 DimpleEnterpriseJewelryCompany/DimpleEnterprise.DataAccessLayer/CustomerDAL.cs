﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DimpleEnterprise.Entities;
using DimpleEnterprise.Exceptions;

namespace DimpleEnterprise.DataAccessLayer
{
    public class CustomerDAL
    {
        public static List<Customer> customerList = new List<Customer>();

        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                customerList.Add(newCustomer);
                customerAdded = true;
            }
            catch (SystemException ex)
            {
                throw new DimpleEnterpriseException(ex.Message);
            }
            return customerAdded;

        }

        public List<Customer> GetAllCustomersDAL()
        {
            return customerList;
        }

        public Customer SearchCustomerDAL(string searchCustomerCity)
        {
            Customer searchCustomer = null;
            try
            {
                searchCustomer = customerList.Find(customer => Equals(customer.City,searchCustomerCity));
            }
            catch (SystemException ex)
            {
                throw new DimpleEnterpriseException(ex.Message);
            }
            return searchCustomer;
        }
    }
}
