﻿using DimpleEnterprise.Entities;
using DimpleEnterprise.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DimpleEnterprise.BusinessLayer;

namespace DimpleEnterprise.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Customer customer1 = new Customer();
                
                int choice;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            ListAllCustomers();
                            break;
                        case 3:
                            SearchCustomer();
                            break;
                        case 6:
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (choice != -1);
            }
            catch (DimpleEnterpriseException ex)
            {
                Console.WriteLine(ex.Message) ;
            }
        }
        private static void SearchCustomer()
        {
            try
            {
                Console.WriteLine("Enter City Name to Search:");
                string searchCity = Console.ReadLine();
                Customer searchCustomer = CustomerBL.SearchCustomerBL(searchCity);
                if (searchCity != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("CustomerID\t\tName\t\tPhoneNumber\t\tAddress\t\tCity\t\tEmail");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", searchCustomer.CustomerID, searchCustomer.CustomerName, searchCustomer.Contact, searchCustomer.Address, searchCustomer.City, searchCustomer.Email);

                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }

            }
            catch (DimpleEnterpriseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ListAllCustomers()
        {
            try
            {
                List<Customer> customerList = CustomerBL.GetAllCustomersBL();
                if (customerList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("CustomerID\t\tName\t\tPhoneNumber\t\tAddress\t\tCity\t\tEmail");
                    Console.WriteLine("******************************************************************************");
                    foreach (Customer customer in customerList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", customer.CustomerID, customer.CustomerName, customer.Contact, customer.Address, customer.City, customer.Email);

                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (DimpleEnterpriseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddCustomer()
        {
            try
            {
                Customer newCustomer = new Customer();
                Console.WriteLine("Enter CustomerID :");
                newCustomer.CustomerID = Console.ReadLine();
                Console.WriteLine("Enter Customer Name :");
                newCustomer.CustomerName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newCustomer.Contact = Console.ReadLine();
                Console.WriteLine("Enter Address :");
                newCustomer.Address = Console.ReadLine();
                Console.WriteLine("Enter City :");
                newCustomer.City = Console.ReadLine();
                Console.WriteLine("Enter Email :");
                newCustomer.Email = Console.ReadLine();
                bool customerAdded = CustomerBL.AddCustomerBL(newCustomer);
                if (customerAdded)
                    Console.WriteLine("Customer Added");
                else
                    Console.WriteLine("Customer not Added");
            }
            catch (DimpleEnterpriseException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Customer Record Menu***********");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. List All Customers");
            Console.WriteLine("3. Search Customer by City");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
