﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1Task4Library;

namespace Q1Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee1[] employees = new Employee1[10];
            for (int k = 0; k < employees.Length; k++)
                employees[k] = new Employee1();
            int counter = 0;
            
            for (int j = 0; j < employees.Length; j++)
            {
                Console.WriteLine("Enter the id of employee {0}", counter);
                employees[j]._EmployeeId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the name of employee {0}", counter);
                employees[j]._EmployeeName = Console.ReadLine();
                Console.WriteLine("Enter the address of employee {0}", counter);
                employees[j]._Address = Console.ReadLine();
                Console.WriteLine("Enter the city of employee {0}", counter);
                employees[j]._City = Console.ReadLine();
                Console.WriteLine("Enter the department of employee {0}", counter);
                employees[j]._Department = Console.ReadLine();
                Console.WriteLine("Enter the salary of employee {0}", counter);
                employees[j]._Salary = Convert.ToDouble(Console.ReadLine());
                counter++;
            }
            counter = 0;
            for (int i = 0; i < employees.Length; i++)
            {
                Console.WriteLine($"Name of employee {counter} is " + employees[i]._EmployeeName + " and salary is " + employees[i]._Salary);
                counter++;
            }
            Console.ReadLine();
        }
    }
}
