﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnwelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome" + txtname.Text + " !!!");
        }

        private void btnwelcome_MouseEnter(object sender, EventArgs e)
        {
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnwelcome_MouseLeave(object sender, EventArgs e)
        {
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnclose.Click += new EventHandler(btnclose_Click_1);
        }

        private void Btnclose_Click(object sender, EventArgs e)
        {
            
        }

        private void btnclose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtname_MouseEnter(object sender, EventArgs e)
        {
            TextBox t = sender as TextBox;
            t.BackColor = Color.Yellow;
        }

        private void txtname_MouseLeave(object sender, EventArgs e)
        {
            TextBox t = sender as TextBox;
            t.BackColor = SystemColors.Control;
        }
    }
}
