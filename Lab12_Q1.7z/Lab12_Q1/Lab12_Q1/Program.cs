﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Lab12_Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            string Line, File;
            Console.WriteLine("Enter the path Of the file");
            File = Console.ReadLine();
            try
            {
                StreamReader Stri = new StreamReader(File);
                Line = Stri.ReadLine();
                while (Line != null)
                {
                    Console.WriteLine(Line);
                    Line = Stri.ReadLine();
                }
                Stri.Close();
                Console.ReadLine();


            }catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
